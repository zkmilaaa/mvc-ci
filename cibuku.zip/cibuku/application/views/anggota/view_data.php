<a href="<?php echo base_url('anggota/tambah');?>" > Tambah Anggota Baru</a>

<TABLE>
    <th>NO</th>
    <th>ANGGOTA</th>
    <TH>ALAMAT</TH>
    <TH>UBAH</TH>
    <TH>HAPUS</TH>
    <?php $id=1;?>
    <?php foreach ($anggota as $a):?>
    <TR>
        <TD><?php echo $id?></TD>
        <TD><?php echo $a['anggota']?></TD>
        <TD><?php echo $a['alamat']?></TD>
        <TD><a href="<?php echo site_url('anggota/get_edit/'.$a['idanggota']);?>" > UBAH</a></TD>
        <TD><a href="<?php echo site_url('anggota/delete/'.$a['idanggota']);?>" > HAPUS</a></TD>
    </TR>
    <?php $id++;?>
<?php endforeach;?>

</TABLE>