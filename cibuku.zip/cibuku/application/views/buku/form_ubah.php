<form action="<?php echo base_url('buku/update');?>" method="post">
    <label>Judul</label>
    <input type="text" name="judul" value="<?php echo $judul_buku?>">
    <input type="hidden" name="id_buku" value="<?php echo $id?>">
    <br>
    <label>Penulis</label>
    <input type="text" name="penulis" value="<?php echo $penulis?>">
    <br>
    <label>Penerbit</label>
    <input type="text" name="penerbit" value="<?php echo $penerbit?>">
    <br>
    <label>Tahun Terbit</label>
    <input type="number" name="thn_terbit" value="<?php echo $thnterbit?>">
    <br>
    <input type="submit" name="simpan" value="Simpan">

</form>