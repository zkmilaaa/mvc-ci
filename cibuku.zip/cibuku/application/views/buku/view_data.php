<a href="<?php echo base_url('buku/tambah');?>" > Tambah Buku Baru</a>

<TABLE>
    <th>NO</th>
    <th>JUDUL</th>
    <th>PENULIS</th>
    <TH>PENERBIT</TH>
    <TH>TAHUN TERBIT</TH>
    <TH>UBAH</TH>
    <TH>HAPUS</TH>
    <?php $id=1;?>
    <?php foreach ($buku as $a):?>
    <TR>
        <TD><?php echo $id?></TD>
        <TD><?php echo $a['judul']?></TD>
        <TD><?php echo $a['penulis']?></TD>
        <TD><?php echo $a['penerbit']?></TD>
        <TD><?php echo $a['thn_terbit']?></TD>
        <TD><a href="<?php echo site_url('buku/get_edit/'.$a['id_buku']);?>" > UBAH</a></TD>
        <TD><a href="<?php echo site_url('buku/delete/'.$a['id_buku']);?>" > HAPUS</a></TD>
    </TR>
    <?php $id++;?>
<?php endforeach;?>

</TABLE>