<form action="<?php echo base_url('buku/insert');?>" method="post">
    <label>Judul</label>
    <input type="text" name="judul">
    <br>
    <label>Penulis</label>
    <input type="text" name="penulis">
    <br>
    <label>Penerbit</label>
    <input type="text" name="penerbit">
    <br>
    <label>Tahun Terbit</label>
    <input type="number" name="thn_terbit">
    <br>
    <input type="submit" name="simpan" value="Simpan">

</form>