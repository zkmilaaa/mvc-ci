<?php
 class Buku extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('M_Buku');
    }
    

    public function index(){
        $this->select();

    }

    public function select(){

         $data['judul']="Data Buku Perpustakaan";
         $data['buku']=$this->M_Buku->Tampil();
         $this->load->view('template/header',$data);
         $this->load->view('buku/view_data',$data);
         $this->load->view('template/footer');


    }

    public function tambah(){
        $data['judul']="Tambah Data Buku Perpustakaan";
        $this->load->view('template/header',$data);
        $this->load->view('buku/form_tambah');
        $this->load->view('template/footer');

    }

    public function insert(){
       // $id=$this->input->post('id_buku');
        $judul=$this->input->post('judul');
        $penulis=$this->input->post('penulis');
        $penerbit=$this->input->post('penerbit');
        $thn_terbit=$this->input->post('thn_terbit');
       //  echo  $judul."-". $penulis."-".$penerbit."-". $thn_terbit;
        $this->M_Buku->save($judul,$penulis,$penerbit,$thn_terbit);
        redirect('buku');
    }

    public function get_edit(){
        $id=$this->uri->segment(3);
        // echo "$id";
        $hasil=$this->M_Buku->pilih_buku($id);
        $i=$hasil->row_array();
        $data = array(
            'id' => $i['id_buku'],
            'judul_buku' => $i['judul'],
            'penulis' => $i['penulis'],
            'penerbit' => $i['penerbit'],
            'thnterbit' => $i['thn_terbit'],
         );

        $data['judul']="Ubah Data Buku Perpustakaan";
        $this->load->view('template/header',$data);
        $this->load->view('buku/form_ubah',$data);
        $this->load->view('template/footer');
    

    }

    public function update(){
        $id=$this->input->post('id_buku');
        $judul=$this->input->post('judul');
        $penulis=$this->input->post('penulis');
        $penerbit=$this->input->post('penerbit');
        $thn_terbit=$this->input->post('thn_terbit');
         echo "$id.$judul.$penulis.$penerbit.$thn_terbit";

       $this->M_Buku->ubah($id,$judul,$penulis,$penerbit,$thn_terbit);
        redirect('buku');
   }
   public function delete(){
    $id=$this->uri->segment(3);
    // echo "hapus". $id;
    $this->M_Buku->delete($id);
    redirect('buku');

   }

 }
?>