<?php
class M_Buku extends CI_Model{

   public function Tampil(){
    $query = $this->db->get('tblbuku');
    $data=$query->result_array();
    return $data;
   }

   public function save($judul,$penulis,$penerbit,$thn_terbit){
      $data = array(
         'judul' => $judul,
         'penulis' => $penulis,
         'penerbit' => $penerbit,
         'thn_terbit' => $thn_terbit,
      );
 
 $this->db->insert('tblbuku', $data);
   }

   public function pilih_buku($id){
      $query = $this->db->get_where('tblbuku', array('id_buku' => $id));
      return $query;

   }

   public function ubah($id,$judul,$penulis,$penerbit,$thn_terbit){

      $data = array(
        'judul' => $judul,
        'penulis' => $penulis,
        'penerbit' => $penerbit,
        'thn_terbit' => $thn_terbit,
      );
 
        $this->db->where('id_buku', $id);
        $this->db->update('tblbuku', $data);
   }
   public function delete($id){
      $this->db->where('id_buku', $id);
      $this->db->delete('tblbuku');

   }

}
?>